-- =========================================================================
--          Smart Parking System — Triggers & Views (SQLite)
-- =========================================================================
-- Converted from MySQL triggers_views.sql
-- Run Order: Run this script THIRD (After schema.sql and seed.sql)
-- =========================================================================

PRAGMA foreign_keys = ON;

-- =========================================================================
-- 1. DROP EXISTING OBJECTS (For idempotency/resets)
-- =========================================================================
DROP TRIGGER IF EXISTS trg_reservation_overlap_check;
DROP TRIGGER IF EXISTS trg_reservation_insert;
DROP TRIGGER IF EXISTS trg_reservation_update;
DROP TRIGGER IF EXISTS trg_reservation_notify;

DROP VIEW IF EXISTS vw_user_reservations;
DROP VIEW IF EXISTS vw_parking_lot_status;
DROP VIEW IF EXISTS vw_pending_payments;

-- =========================================================================
-- 2. DATABASE AUTOMATION: TRIGGERS
-- =========================================================================

-- -------------------------------------------------------------------------
-- TRIGGER A: trg_reservation_overlap_check (Concurrency & Domain Integrity)
-- Type: BEFORE INSERT (Validation Safeguard)
-- Purpose: Protects the database against race conditions and double bookings.
-- SQLite Note: Uses RAISE(ABORT, ...) instead of MySQL SIGNAL SQLSTATE.
-- -------------------------------------------------------------------------
CREATE TRIGGER trg_reservation_overlap_check
BEFORE INSERT ON Reservation
FOR EACH ROW
BEGIN
    SELECT RAISE(ABORT, 'This slot is already booked for the selected time range.')
    WHERE EXISTS (
        SELECT 1 FROM Reservation
        WHERE slot_id = NEW.slot_id
        AND status IN ('Booked', 'Active')
        AND (
            (NEW.start_time BETWEEN start_time AND end_time) OR
            (NEW.end_time BETWEEN start_time AND end_time) OR
            (start_time BETWEEN NEW.start_time AND NEW.end_time)
        )
    );
END;

-- -------------------------------------------------------------------------
-- TRIGGER B: trg_reservation_insert (Spatial State Allocation)
-- Type: AFTER INSERT (Synchronous Trigger)
-- Purpose: Flips the parking slot status to 'Reserved' on new booking.
-- -------------------------------------------------------------------------
CREATE TRIGGER trg_reservation_insert
AFTER INSERT ON Reservation
FOR EACH ROW
BEGIN
    UPDATE Parking_Slot
    SET availability_status = 'Reserved'
    WHERE slot_id = NEW.slot_id;
END;

-- -------------------------------------------------------------------------
-- TRIGGER C: trg_reservation_update (Spatial State Machine Manager)
-- Type: AFTER UPDATE (State Synchronizer)
-- Purpose: Manages parking slot status as booking state changes.
-- SQLite Note: Uses CASE-style logic via multiple WHEN conditions.
-- -------------------------------------------------------------------------
CREATE TRIGGER trg_reservation_update
AFTER UPDATE ON Reservation
FOR EACH ROW
WHEN NEW.status != OLD.status
BEGIN
    UPDATE Parking_Slot
    SET availability_status = CASE NEW.status
        WHEN 'Active'     THEN 'Occupied'
        WHEN 'Completed'  THEN 'Available'
        WHEN 'Cancelled'  THEN 'Available'
        WHEN 'Booked'     THEN 'Reserved'
        ELSE availability_status
    END
    WHERE slot_id = NEW.slot_id;
END;

-- -------------------------------------------------------------------------
-- TRIGGER D: trg_reservation_notify (Database-Level Notifications)
-- Type: AFTER INSERT (Audit Event)
-- Purpose: Generates an unread system notification on successful booking.
-- SQLite Note: Uses || for string concatenation instead of CONCAT().
-- -------------------------------------------------------------------------
CREATE TRIGGER trg_reservation_notify
AFTER INSERT ON Reservation
FOR EACH ROW
BEGIN
    INSERT INTO Notification(user_id, message, type, is_read)
    VALUES (
        NEW.user_id,
        'Your reservation (ID: ' || NEW.reservation_id || ') has been successfully booked.',
        'Reservation',
        0
    );
END;

-- =========================================================================
-- 3. REPORTING LAYERS: AUDITING VIEWS
-- =========================================================================

-- VIEW A: vw_user_reservations
-- Purpose: Compiles driver details and booking records for history audits.
CREATE VIEW vw_user_reservations AS
SELECT u.user_id, u.full_name,
       r.reservation_id, r.start_time, r.end_time,
       r.total_amount, r.status
FROM User u
JOIN Reservation r ON u.user_id = r.user_id;

-- VIEW B: vw_parking_lot_status
-- Purpose: Dynamically calculates the live capacity of each parking lot.
CREATE VIEW vw_parking_lot_status AS
SELECT pl.lot_id, pl.name, pl.total_slots,
       SUM(CASE WHEN ps.availability_status = 'Available' THEN 1 ELSE 0 END) AS available_slots
FROM Parking_Lot pl
JOIN Parking_Slot ps ON pl.lot_id = ps.lot_id
GROUP BY pl.lot_id, pl.name, pl.total_slots;

-- VIEW C: vw_pending_payments
-- Purpose: Isolates unpaid transactions for tracking cash and digital audits.
CREATE VIEW vw_pending_payments AS
SELECT r.reservation_id,
       u.full_name,
       pl.name AS parking_lot,
       p.amount,
       p.payment_status
FROM Reservation r
JOIN Payment p ON r.reservation_id = p.reservation_id
JOIN User u ON r.user_id = u.user_id
JOIN Parking_Slot ps ON r.slot_id = ps.slot_id
JOIN Parking_Lot pl ON ps.lot_id = pl.lot_id
WHERE p.payment_status = 'Pending';

-- =========================================================================
-- 4. VERIFICATION SCRIPTS
-- =========================================================================
SELECT
    (SELECT COUNT(*) FROM User) AS Total_Users,
    (SELECT COUNT(*) FROM Parking_Lot) AS Total_Lots,
    (SELECT COUNT(*) FROM Reservation) AS Total_Reservations;

SELECT
    (SELECT COUNT(*) FROM User) AS Users,
    (SELECT COUNT(*) FROM Parking_Lot) AS Lots,
    (SELECT COUNT(*) FROM Parking_Slot) AS Slots,
    (SELECT COUNT(*) FROM Reservation) AS Reservations,
    (SELECT COUNT(*) FROM Payment) AS Payments;
