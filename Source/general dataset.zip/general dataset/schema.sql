-- =========================================
-- Smart Parking System — Schema (SQLite)
-- Converted from MySQL schema.sql
-- Run FIRST, then seed.sql, then triggers_views.sql
-- =========================================

PRAGMA foreign_keys = ON;

-- =========================================
-- Smart Parking System — Schema
-- Run this FIRST, then seed.sql, then triggers_views.sql
-- =========================================


-- =========================================
-- Drop existing objects (reverse dependency order)
-- =========================================
DROP VIEW IF EXISTS vw_pending_payments;
DROP VIEW IF EXISTS vw_parking_lot_status;
DROP VIEW IF EXISTS vw_user_reservations;

DROP TRIGGER IF EXISTS trg_reservation_overlap_check;
DROP TRIGGER IF EXISTS trg_reservation_insert;
DROP TRIGGER IF EXISTS trg_reservation_update;
DROP TRIGGER IF EXISTS trg_reservation_notify;

DROP TABLE IF EXISTS Notification;
DROP TABLE IF EXISTS Review;
DROP TABLE IF EXISTS Payment;
DROP TABLE IF EXISTS Reservation;
DROP TABLE IF EXISTS Vehicle;
DROP TABLE IF EXISTS Parking_Slot;
DROP TABLE IF EXISTS Parking_Lot;
DROP TABLE IF EXISTS User;
DROP TABLE IF EXISTS Role;

-- =========================================
-- 1. Role
-- =========================================
CREATE TABLE Role (
    role_id INT PRIMARY KEY ,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description VARCHAR(255)
);

-- =========================================
-- 2. User
-- =========================================
CREATE TABLE User (
    user_id INT PRIMARY KEY ,
    role_id INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    balance DECIMAL(10,2) DEFAULT 0.00 CHECK (balance >= 0),
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Suspended', 'Inactive', 'Deleted')),
    FOREIGN KEY (role_id) REFERENCES Role(role_id)
        
        
);

-- =========================================
-- 3. Parking_Lot
-- =========================================
CREATE TABLE Parking_Lot (
    lot_id INT PRIMARY KEY ,
    owner_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(255),
    latitude DECIMAL(10,6),
    longitude DECIMAL(10,6),
    total_slots INT CHECK (total_slots > 0),
    price_per_hour DECIMAL(10,2) CHECK (price_per_hour >= 0),
    opening_time TEXT,
    closing_time TEXT,
    status VARCHAR(20) DEFAULT 'Open',
    FOREIGN KEY (owner_id) REFERENCES User(user_id)
        
        
);

-- =========================================
-- 4. Parking_Slot
-- =========================================
CREATE TABLE Parking_Slot (
    slot_id INT PRIMARY KEY ,
    lot_id INT NOT NULL,
    slot_number VARCHAR(10) NOT NULL,
    slot_type VARCHAR(20) NOT NULL,
    availability_status VARCHAR(20) DEFAULT 'Available',
    UNIQUE (slot_number, lot_id),
    FOREIGN KEY (lot_id) REFERENCES Parking_Lot(lot_id)
        ON DELETE CASCADE
        
);

-- =========================================
-- 5. Vehicle
-- =========================================
CREATE TABLE Vehicle (
    vehicle_id INT PRIMARY KEY ,
    user_id INT NOT NULL,
    plate_number VARCHAR(20) UNIQUE NOT NULL,
    vehicle_type VARCHAR(20),
    color VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES User(user_id)
        ON DELETE CASCADE
        
);

-- =========================================
-- 6. Reservation
-- =========================================
CREATE TABLE Reservation (
    reservation_id INT PRIMARY KEY ,
    user_id INT NOT NULL,
    slot_id INT NOT NULL,
    vehicle_id INT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    price_at_booking DECIMAL(10,2),
    total_amount DECIMAL(10,2),
    status VARCHAR(20) CHECK (status IN ('Booked', 'Active', 'Completed', 'Cancelled', 'Overdue')) DEFAULT 'Booked',
    FOREIGN KEY (user_id) REFERENCES User(user_id)
        
        ,
    FOREIGN KEY (slot_id) REFERENCES Parking_Slot(slot_id)
        
        ,
    FOREIGN KEY (vehicle_id) REFERENCES Vehicle(vehicle_id)
        
        
);

-- =========================================
-- 7. Payment
-- =========================================
CREATE TABLE Payment (
    payment_id INT PRIMARY KEY ,
    reservation_id INT NOT NULL,
    amount DECIMAL(10,2) CHECK (amount >= 0),
    payment_method VARCHAR(20) CHECK (payment_method IN ('Cash', 'Card', 'App', 'Wallet')),
    payment_status VARCHAR(20) DEFAULT 'Pending' CHECK (payment_status IN ('Pending', 'Paid', 'Failed', 'Refunded')),
    payment_date TEXT DEFAULT CURRENT_TIMESTAMP,
    transaction_reference VARCHAR(50) UNIQUE,
    FOREIGN KEY (reservation_id) REFERENCES Reservation(reservation_id)
        ON DELETE CASCADE
        
);

-- =========================================
-- 8. Review
-- =========================================
CREATE TABLE Review (
    review_id INT PRIMARY KEY ,
    user_id INT NOT NULL,
    lot_id INT NOT NULL,
    reservation_id INT NULL,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    comment VARCHAR(255),
    review_date TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(user_id)
        ON DELETE CASCADE,
    FOREIGN KEY (lot_id) REFERENCES Parking_Lot(lot_id)
        ON DELETE CASCADE,
    FOREIGN KEY (reservation_id) REFERENCES Reservation(reservation_id)
        ON DELETE SET NULL
);

-- =========================================
-- 9. Notification
-- =========================================
CREATE TABLE Notification (
    notification_id INT PRIMARY KEY ,
    user_id INT NOT NULL,
    message VARCHAR(255),
    type VARCHAR(50),
    is_read INTEGER DEFAULT FALSE,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(user_id)
        ON DELETE CASCADE
);

-- =========================================
-- INDEXES (Performance Optimization)
-- =========================================
CREATE INDEX idx_slot_lot ON Parking_Slot(lot_id);
CREATE INDEX idx_slot_lot_status ON Parking_Slot(lot_id, availability_status);
CREATE INDEX idx_reservation_slot_time ON Reservation(slot_id, start_time, end_time);
CREATE INDEX idx_reservation_user ON Reservation(user_id);
CREATE INDEX idx_payment_reservation ON Payment(reservation_id);
CREATE INDEX idx_user_role ON User(role_id);
CREATE INDEX idx_review_lot ON Review(lot_id);